export type Crudentials = {
  email: string,
  password: string,
};
