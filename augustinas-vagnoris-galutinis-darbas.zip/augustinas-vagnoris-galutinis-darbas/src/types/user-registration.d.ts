export type UserRegistration = {
  email: string,
  password: string,
  repeatPassword: string,
};
