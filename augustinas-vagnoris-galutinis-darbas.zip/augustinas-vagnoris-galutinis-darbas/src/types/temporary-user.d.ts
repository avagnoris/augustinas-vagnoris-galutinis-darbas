export type TemporaryUser = {
  id: string,
  name: string,
  email: string,
  password: string,
  surname: string,
  img: string,
};
